/* Some implementations of ar cannot create an empty archive. */
int libdpkg_empty_dummy_symbol;
